# Unity Scripting
A collection of fun from our Unity Scripting tutorial series.

# Audio Visualizer With Spectrum Data

https://youtu.be/PzVbaaxgPco

We can't wait to see what creative stuff you guys come up with using the AudioSyncer! If you share your visualizers @RenaissanceCode we will retweet you!
