namespace UnityEngine.PostProcessing
{
    public sealed class TrackballGroupAttribute : PropertyAttribute
    {
    }
}
